 SQLite
========

 Huh?
------

   This is my personal solution to the lackluster and somewhat nonsensical SQLite distribution practices.
